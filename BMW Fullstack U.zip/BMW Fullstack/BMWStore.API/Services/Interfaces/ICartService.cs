﻿using BMWStore.API.DTOs;

namespace BMWStore.API.Services.Interfaces
{
    public interface ICartService
    {
        List<Dictionary<string, object>> Add(CartDTO dto);
        List<Dictionary<string, object>> Get(int userId);
        List<Dictionary<string, object>> Remove(int cartId);
        List<Dictionary<string, object>> UpdateQty(CartDTO dto);
    }
}