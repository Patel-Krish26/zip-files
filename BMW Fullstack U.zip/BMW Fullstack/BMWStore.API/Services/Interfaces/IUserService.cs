﻿using BMWStore.API.DTOs;

namespace BMWStore.API.Services.Interfaces
{
    public interface IUserService
    {
        List<Dictionary<string, object>> Register(UserDTO dto);
        List<Dictionary<string, object>> Login(LoginDTO dto);
        List<Dictionary<string, object>> GetAll();
        List<Dictionary<string, object>> GetById(int id);
        List<Dictionary<string, object>> Update(UserDTO dto);
        List<Dictionary<string, object>> Delete(int id);
    }
}