﻿using BMWStore.API.DTOs;

namespace BMWStore.API.Services.Interfaces
{
    public interface IProductService
    {
        List<Dictionary<string, object>> GetAll();
        List<Dictionary<string, object>> GetById(int id);
        List<Dictionary<string, object>> Add(ProductDTO dto);
        List<Dictionary<string, object>> Update(ProductDTO dto);
        List<Dictionary<string, object>> Delete(int id);
    }
}