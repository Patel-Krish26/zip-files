﻿using BMWStore.API.DAL;
using BMWStore.API.DTOs;
using BMWStore.API.Services.Interfaces;
using Microsoft.Data.SqlClient;

namespace BMWStore.API.Services.Implementations
{
    public class CartService : ICartService
    {
        private readonly DbHelper _db;

        public CartService(DbHelper db)
        {
            _db = db;
        }

        public List<Dictionary<string, object>> Add(CartDTO dto)
        {
            SqlParameter[] p = {
                new SqlParameter("@action","add"),
                new SqlParameter("@user_id",dto.UserId),
                new SqlParameter("@product_id",dto.ProductId),
                new SqlParameter("@qty",dto.Qty)
            };

            return _db.ExecuteProcedure("sp_cart", p);
        }

        public List<Dictionary<string, object>> Get(int userId)
        {
            SqlParameter[] p = {
                new SqlParameter("@action","get"),
                new SqlParameter("@user_id",userId)
            };

            return _db.ExecuteProcedure("sp_cart", p);
        }

        public List<Dictionary<string, object>> Remove(int cartId)
        {
            SqlParameter[] p = {
                new SqlParameter("@action","remove"),
                new SqlParameter("@cart_id",cartId)
            };

            return _db.ExecuteProcedure("sp_cart", p);
        }

        public List<Dictionary<string, object>> UpdateQty(CartDTO dto)
        {
            SqlParameter[] p = {
                new SqlParameter("@action","updateqty"),
                new SqlParameter("@cart_id",dto.CartId),
                new SqlParameter("@qty",dto.Qty)
            };

            return _db.ExecuteProcedure("sp_cart", p);
        }
    }
}