﻿using BMWStore.API.DAL;
using BMWStore.API.DTOs;
using BMWStore.API.Services.Interfaces;
using Microsoft.Data.SqlClient;

namespace BMWStore.API.Services.Implementations
{
    public class ProductService : IProductService
    {
        private readonly DbHelper _db;

        public ProductService(DbHelper db)
        {
            _db = db;
        }

        // ✅ GET ALL PRODUCTS
        public List<Dictionary<string, object>> GetAll()
        {
            SqlParameter[] p = {
                new SqlParameter("@action", "getall")
            };

            return _db.ExecuteProcedure("sp_product", p);
        }

        // ✅ GET PRODUCT BY ID
        public List<Dictionary<string, object>> GetById(int id)
        {
            SqlParameter[] p = {
                new SqlParameter("@action", "getbyid"),
                new SqlParameter("@product_id", id)
            };

            return _db.ExecuteProcedure("sp_product", p);
        }

        // ✅ ADD PRODUCT
        public List<Dictionary<string, object>> Add(ProductDTO dto)
        {
            SqlParameter[] p = {
                new SqlParameter("@action","add"),
                new SqlParameter("@name", dto.Name),
                new SqlParameter("@price", dto.Price),
                new SqlParameter("@img", dto.Img),
                new SqlParameter("@description", dto.Description)
            };

            return _db.ExecuteProcedure("sp_product", p);
        }

        // ✅ UPDATE PRODUCT
        public List<Dictionary<string, object>> Update(ProductDTO dto)
        {
            SqlParameter[] p = {
                new SqlParameter("@action","update"),
                new SqlParameter("@product_id", dto.ProductId),
                new SqlParameter("@name", dto.Name),
                new SqlParameter("@price", dto.Price),
                new SqlParameter("@img", dto.Img),
                new SqlParameter("@description", dto.Description)
            };

            return _db.ExecuteProcedure("sp_product", p);
        }

        // ✅ DELETE PRODUCT
        public List<Dictionary<string, object>> Delete(int id)
        {
            SqlParameter[] p = {
                new SqlParameter("@action","delete"),
                new SqlParameter("@product_id", id)
            };

            return _db.ExecuteProcedure("sp_product", p);
        }
    }
}