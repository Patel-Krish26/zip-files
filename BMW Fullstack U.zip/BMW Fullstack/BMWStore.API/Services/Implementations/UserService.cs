﻿using BMWStore.API.DAL;
using BMWStore.API.DTOs;
using BMWStore.API.Services.Interfaces;
using Microsoft.Data.SqlClient;

namespace BMWStore.API.Services.Implementations
{
    public class UserService : IUserService
    {
        private readonly DbHelper _db;

        public UserService(DbHelper db)
        {
            _db = db;
        }

        // ✅ REGISTER
        public List<Dictionary<string, object>> Register(UserDTO dto)
        {
            SqlParameter[] p = {
                new SqlParameter("@action","register"),
                new SqlParameter("@name",dto.Name),
                new SqlParameter("@email",dto.Email),
                new SqlParameter("@password",dto.Password)
            };

            return _db.ExecuteProcedure("sp_user", p);
        }

        // ✅ LOGIN
        public List<Dictionary<string, object>> Login(LoginDTO dto)
        {
            SqlParameter[] p = {
                new SqlParameter("@action","login"),
                new SqlParameter("@email",dto.Email),
                new SqlParameter("@password",dto.Password)
            };

            return _db.ExecuteProcedure("sp_user", p);
        }

        // ✅ GET ALL
        public List<Dictionary<string, object>> GetAll()
        {
            SqlParameter[] p = {
                new SqlParameter("@action","getall")
            };

            return _db.ExecuteProcedure("sp_user", p);
        }

        // ✅ GET BY ID
        public List<Dictionary<string, object>> GetById(int id)
        {
            SqlParameter[] p = {
                new SqlParameter("@action","getbyid"),
                new SqlParameter("@user_id",id)
            };

            return _db.ExecuteProcedure("sp_user", p);
        }

        // ✅ UPDATE
        public List<Dictionary<string, object>> Update(UserDTO dto)
        {
            SqlParameter[] p = {
                new SqlParameter("@action","update"),
                new SqlParameter("@user_id",dto.UserId),
                new SqlParameter("@name",dto.Name),
                new SqlParameter("@email",dto.Email),
                new SqlParameter("@password",dto.Password)
            };

            return _db.ExecuteProcedure("sp_user", p);
        }

        // ✅ DELETE
        public List<Dictionary<string, object>> Delete(int id)
        {
            SqlParameter[] p = {
                new SqlParameter("@action","delete"),
                new SqlParameter("@user_id",id)
            };

            return _db.ExecuteProcedure("sp_user", p);
        }
    }
}