﻿using System.Data;
using Microsoft.Data.SqlClient;

namespace BMWStore.API.DAL
{
    public class DbHelper
    {
        private readonly string _connectionString;

        public DbHelper(IConfiguration config)
        {
            _connectionString = config.GetConnectionString("DefaultConnection");
        }

        public List<Dictionary<string, object>> ExecuteProcedure(string sp, SqlParameter[] parameters)
        {
            using SqlConnection con = new SqlConnection(_connectionString);
            using SqlCommand cmd = new SqlCommand(sp, con);

            cmd.CommandType = CommandType.StoredProcedure;

            if (parameters != null)
                cmd.Parameters.AddRange(parameters);

            con.Open();

            using SqlDataReader reader = cmd.ExecuteReader();
            var result = new List<Dictionary<string, object>>();


            while (reader.Read())
            {
                var row = new Dictionary<string, object>();

                for (int i = 0; i < reader.FieldCount; i++)
                {
                    row[reader.GetName(i)] = reader[i];
                }

                result.Add(row);
            }

            return result;
        }
    }
}