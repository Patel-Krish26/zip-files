﻿using BMWStore.API.DTOs;
using BMWStore.API.Services.Interfaces;
using Microsoft.AspNetCore.Mvc;

namespace BMWStore.API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class CartController : ControllerBase
    {
        private readonly ICartService _service;

        public CartController(ICartService service)
        {
            _service = service;
        }

        [HttpPost("add")]
        public IActionResult Add(CartDTO dto)
        {
            return Ok(_service.Add(dto));
        }

        [HttpGet("{userId}")]
        public IActionResult Get(int userId)
        {
            return Ok(_service.Get(userId));
        }

        [HttpDelete("{cartId}")]
        public IActionResult Remove(int cartId)
        {
            return Ok(_service.Remove(cartId));
        }

        [HttpPut("update")]
        public IActionResult UpdateQty(CartDTO dto)
        {
            return Ok(_service.UpdateQty(dto));
        }
    }
}