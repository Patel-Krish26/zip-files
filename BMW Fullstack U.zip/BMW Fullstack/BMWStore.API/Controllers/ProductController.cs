﻿using BMWStore.API.DTOs;
using BMWStore.API.Services.Interfaces;
using Microsoft.AspNetCore.Mvc;

namespace BMWStore.API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class ProductController : ControllerBase
    {
        private readonly IProductService _service;

        public ProductController(IProductService service)
        {
            _service = service;
        }

        [HttpGet]
        public IActionResult GetAll()
        {
            return Ok(_service.GetAll());
        }

        [HttpGet("{id}")]
        public IActionResult GetById(int id)
        {
            return Ok(_service.GetById(id));
        }

        [HttpPost]
        public IActionResult Add(ProductDTO dto)
        {
            return Ok(_service.Add(dto));
        }

        [HttpPut]
        public IActionResult Update(ProductDTO dto)
        {
            return Ok(_service.Update(dto));
        }

        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            return Ok(_service.Delete(id));
        }
    }
}