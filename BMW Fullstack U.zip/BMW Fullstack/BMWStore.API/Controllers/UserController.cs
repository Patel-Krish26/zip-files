﻿using BMWStore.API.DTOs;
using BMWStore.API.Services.Interfaces;
using Microsoft.AspNetCore.Mvc;

namespace BMWStore.API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class UserController : ControllerBase
    {
        private readonly IUserService _service;

        public UserController(IUserService service)
        {
            _service = service;
        }

        [HttpPost("register")]
        public IActionResult Register(UserDTO dto)
        {
            return Ok(_service.Register(dto));
        }

        [HttpPost("login")]
        public IActionResult Login(LoginDTO dto)
        {
            return Ok(_service.Login(dto));
        }

        [HttpGet]
        public IActionResult GetAll()
        {
            return Ok(_service.GetAll());
        }

        [HttpGet("{id}")]
        public IActionResult GetById(int id)
        {
            return Ok(_service.GetById(id));
        }

        [HttpPut]
        public IActionResult Update(UserDTO dto)
        {
            return Ok(_service.Update(dto));
        }

        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            return Ok(_service.Delete(id));
        }
    }
}